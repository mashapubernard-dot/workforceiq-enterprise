'use client';

import { useState } from 'react';
import { LayoutDashboard, CalendarDays, Users, ClipboardCheck, BarChart3, Package, Bell, MapPin, Camera, Menu } from 'lucide-react';

const nav = [
  ['Dashboard', LayoutDashboard],
  ['Schedules', CalendarDays],
  ['People', Users],
  ['Performance', BarChart3],
  ['QA & Coaching', ClipboardCheck],
  ['Inventory', Package],
  ['Alerts', Bell],
];

export default function WorkforceIQ() {
  const [active, setActive] = useState('Dashboard');
  const [mobile, setMobile] = useState(false);

  return (
    <main className="min-h-screen bg-white text-slate-950 dark:bg-slate-950 dark:text-white">
      <style jsx global>{`
        *{box-sizing:border-box} body{margin:0;font-family:Inter,ui-sans-serif,system-ui,sans-serif}
        .app{display:flex;min-height:100vh}.side{width:250px;border-right:1px solid #e5e7eb;padding:20px;background:white}
        .dark .side{background:#0f172a;border-color:#1e293b}.content{flex:1}.top{height:72px;border-bottom:1px solid #e5e7eb;display:flex;align-items:center;justify-content:space-between;padding:0 28px}
        .grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px;padding:24px}.card{border:1px solid #e5e7eb;border-radius:14px;padding:18px;background:white}
        .dark .card{background:#111827;border-color:#263244}.metric{font-size:28px;font-weight:750}.muted{color:#64748b;font-size:13px}.btn{border:1px solid #e2e8f0;border-radius:10px;padding:9px 13px;background:white;cursor:pointer}.primary{background:#dc2626;color:white;border-color:#dc2626}
        .navbtn{width:100%;display:flex;gap:10px;align-items:center;padding:11px;border:0;border-radius:10px;background:transparent;text-align:left;cursor:pointer}.navbtn:hover,.selected{background:#fee2e2;color:#991b1b}
        .brand{font-weight:800;font-size:20px;margin-bottom:28px}.logo{display:inline-grid;place-items:center;width:32px;height:32px;border-radius:9px;background:#dc2626;color:white;margin-right:8px}
        .chart{height:220px;display:flex;align-items:end;gap:12px;padding-top:20px}.bar{flex:1;background:#dc2626;border-radius:6px 6px 0 0;min-width:14px}.table{width:100%;border-collapse:collapse}.table th,.table td{padding:12px;border-bottom:1px solid #e5e7eb;text-align:left;font-size:14px}
        @media(max-width:850px){.side{display:none}.grid{grid-template-columns:1fr 1fr;padding:14px}.top{padding:0 14px}.mobile{display:block!important}}
        @media(max-width:550px){.grid{grid-template-columns:1fr}.metric{font-size:24px}.chart{height:180px}}
      `}</style>

      <div className="app">
        <aside className="side">
          <div className="brand"><span className="logo">W</span>WorkforceIQ</div>
          <div className="muted" style={{marginBottom:10}}>ACME RETAIL · Johannesburg</div>
          {nav.map(([name, Icon]) => (
            <button key={name} className={`navbtn ${active===name?'selected':''}`} onClick={()=>setActive(name)}>
              <Icon size={18}/>{name}
            </button>
          ))}
          <div style={{marginTop:30}} className="muted">Role</div>
          <strong>Admin</strong>
        </aside>

        <section className="content">
          <header className="top">
            <div><button className="btn mobile" style={{display:'none'}} onClick={()=>setMobile(!mobile)}><Menu size={18}/></button> <strong>{active}</strong></div>
            <div style={{display:'flex',gap:8,alignItems:'center'}}><span className="muted">Thu, 13 Aug 2026</span><button className="btn">BS</button></div>
          </header>

          <div className="grid">
            <Metric title="Present today" value="84" sub="+6 vs yesterday"/>
            <Metric title="Scheduled" value="96" sub="87.5% coverage"/>
            <Metric title="Sales today" value="R184,620" sub="+12.4% vs target"/>
            <Metric title="Labor cost" value="R62,410" sub="33.8% of sales"/>

            <div className="card" style={{gridColumn:'span 2'}}>
              <h3>Sales per Agent</h3><p className="muted">Today · South Africa</p>
              <div className="chart">{[55,78,46,92,70,61,83,50,74,65].map((h,i)=><div className="bar" style={{height:`${h}%`}} key={i}/>)}</div>
            </div>

            <div className="card">
              <h3>Adherence</h3><p className="muted">Scheduled vs actual time</p>
              <div className="metric" style={{marginTop:30}}>91.8%</div>
              <div style={{marginTop:20,height:10,borderRadius:8,background:'#e2e8f0'}}><div style={{width:'92%',height:10,borderRadius:8,background:'#dc2626'}}/></div>
            </div>

            <div className="card">
              <h3>Alerts</h3>
              <p>🔴 3 agents late</p><p>🟠 2 below sales target</p><p>🟡 4 low-stock SKUs</p>
              <button className="btn primary" onClick={()=>setActive('Alerts')}>View alerts</button>
            </div>

            <div className="card" style={{gridColumn:'1 / -1'}}>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}><div><h3>Live team</h3><p className="muted">Clock-in status with GPS verification</p></div><button className="btn primary">Export</button></div>
              <table className="table"><thead><tr><th>Employee</th><th>Branch</th><th>Status</th><th>Clock-in</th><th>Location</th><th>Sales</th></tr></thead>
              <tbody>{[['Thabo Mokoena','Sandton','Working','07:58','Verified','R18,420'],['Lerato Dlamini','Rosebank','Late','08:21','Verified','R7,120'],['Anele Ndlovu','Midrand','Working','07:55','Verified','R15,890'],['Sipho Khumalo','Sandton','Break','08:02','Verified','R11,330']].map(r=><tr key={r[0]}>{r.map((x,i)=><td key={i}>{x}</td>)}</tr>)}</tbody></table>
            </div>

            <div className="card" style={{gridColumn:'1 / -1'}}>
              <h3>Agent mobile actions</h3>
              <p className="muted">The production flow captures browser/device GPS and a photo before submitting the clock-in to Supabase Storage.</p>
              <button className="btn primary" onClick={()=>alert('Demo: request GPS + camera permissions, then upload photo to Supabase bucket clockin-photos.') }><MapPin size={16}/> Clock In with GPS + Photo</button>
            </div>
          </div>
        </section>
      </div>
    </main>
  )
}

function Metric({title,value,sub}:{title:string,value:string,sub:string}){
 return <div className="card"><div className="muted">{title}</div><div className="metric">{value}</div><div className="muted">{sub}</div></div>
}
